package tcpong;

import processing.core.PApplet;

abstract class PongClient {
    public static void main(String[] args) {
        var pg = PongGame.newClient("localhost", 8080);
        PApplet.runSketch(new String[]{"PongGame"}, pg);
    }

}
