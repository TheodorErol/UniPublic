package tcpong;

import java.io.*;
import java.lang.reflect.Array;
import java.net.ServerSocket;
import java.net.Socket;
import tcpong.PongGame.Ball;

public class ClientServerThread extends Thread {

    private ServerSocket serverSocket;
    private Socket socket;
    private PongGame pongGame;
    private ObjectOutputStream oos;

    private boolean server;
    private int z = 0;

    private ClientServerThread(PongGame pongGame) {
        this.pongGame = pongGame;
    }

    /*
    Constructor for a server thread
     */
    public  static ClientServerThread newServer(int port, PongGame pongGame) {
        var cst = new ClientServerThread(pongGame);
        cst.server = true;
        try {
            cst.serverSocket = new ServerSocket(port);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return cst;
    }

    /*
    Constructor for a client thread
     */
    public static ClientServerThread newClient(String ip, int port, PongGame pongGame) {
        var cst = new ClientServerThread(pongGame);
        cst.server = false;
        try {
            cst.socket = new Socket(ip, port);
            cst.oos = new ObjectOutputStream(cst.socket.getOutputStream());
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return cst;
    }

    public boolean isConnected() {
        return socket != null && socket.isConnected();
    }

    public boolean isServer() {
        return server;
    }

    public void otherPlayerMove(String move) {
        try {
            if(oos != null) {
                oos.writeObject(move);
            }
        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void run() {
        try {
            if (socket == null) {
                socket = serverSocket.accept();
                oos = new ObjectOutputStream(socket.getOutputStream());
            }

            var ois = new ObjectInputStream(socket.getInputStream());
            while(true) {
                Object obj = ois.readObject();
                if(obj instanceof String) {
                    {
                        switch ((String) obj) {
                            case "UP1" -> {pongGame.player1.moveUP();}
                            case "DOWN1" -> {pongGame.player1.moveDOWN();}
                            case "UP2" -> {pongGame.player2.moveUP();}
                            case "DOWN2" -> {pongGame.player2.moveDOWN();}
                        }
                    }
                }
            }

        }
        catch (IOException e) {
            throw new RuntimeException(e);
        }
        catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

    }

}
