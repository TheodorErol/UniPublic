package tcpong;

import processing.core.PApplet;

import java.io.Serializable;

public class PongGame extends PApplet {

    private ClientServerThread thread;

    //Creates a new PongGame server
    public static PongGame newServer(int port) {
        var pg = new PongGame();
        pg.thread = ClientServerThread.newServer(port, pg);
        pg.thread.start();
        return pg;
    }

    //Creates a new PongGame client
    public static PongGame newClient(String ip, int port) {
        var pg = new PongGame();
        pg.thread = ClientServerThread.newClient(ip, port, pg);
        pg.thread.start();
        return pg;
    }

    @Override
    public void settings() {
        setSize(400, 400);
    }

    Player player1;
    Player player2;
    public Ball spielBall;
    //public boolean gameOver = false;
    @Override
    public void setup() {
        player1 = new Player(20);
        player2 = new Player(360);
        spielBall = new Ball(20, 20);
    }

    @Override
    public void draw() {
        fill(0);
        textAlign(CENTER, CENTER);
        text("Warten auf zweiten Spieler", 200, 200);
        textSize(20);
        if(thread.isConnected()) {
            background(0);
            rect(player1.x, player1.y, player1.width, player1.height);
            rect(player2.x, player2.y, player2.width, player2.height);
            ellipse(spielBall.x, spielBall.y, spielBall.widthBound, spielBall.heightBound);
            spielBall.spielStart();
            spielBall.collisionCheck();
            stroke(255);
            drawCenterLine();
        }
        /*else if (thread.isConnected() && isGameOver()) {
            background(255);
            text("GAME OVER", 200, 200);
        }*/
    }


    private void drawCenterLine() {
        int a = 0;
        for(int i = 0; i < 10; i++) {
            line(200, a, 200, a + 30);
            a = a + 41;
        }
    }

    /*private boolean isGameOver() {
       return gameOver;
    }*/

    @Override
    public void keyPressed() {
        if(key == CODED) {
            if(keyCode == UP) {
                if(thread.isServer()) {
                    thread.otherPlayerMove("UP1");
                    player1.moveUP();
                }
                else {
                    thread.otherPlayerMove("UP2");
                    player2.moveUP();
                }
            }
            if(keyCode == DOWN) {
                if(thread.isServer()) {
                    thread.otherPlayerMove("DOWN1");
                    player1.moveDOWN();
                }
                else {
                    thread.otherPlayerMove("DOWN2");
                    player2.moveDOWN();
                }
            }
        }
    }

    //Player Rect

    class Player {
        int x, y, width, height, collisioncheckx, collisionchecky;

        private Player(int x) {
            this.height = 100;
            this.width = 20;
            this.y = 150;
            this.x = x;
            this.collisioncheckx = this.x + 10;
            this.collisionchecky = this.y + 50;
        }

        void moveUP() {
            if(this.y >= 5) {
                this.y = this.y - 3;
                this.collisionchecky = this.y + 50;
            }
        }

        void moveDOWN() {
            if(this.y <= 295) {
                this.y = this.y + 3;
                this.collisionchecky = this.y + 50;
            }
        }


    }

    //Ball

    public class Ball implements Serializable{
        float x, y;
        int widthBound, heightBound;
        float directionx;
        float directiony;


        Ball(int widthBound, int heightBound) {
            this.widthBound = widthBound;
            this.heightBound = heightBound;
            this.x = 200;
            this.y = 20;
            this.directiony = 3;
            this.directionx = -3;

        }


        void spielStart() {
            this.x = this.directionx + this.x;
            this.y = this.directiony + this.y;
            checkEdge();
        }

        void checkEdge () {
            if (this.x >= 380) {
                this.directionx = this.directionx * -1;
            }
            else if (this.x <= 19) {
                this.directionx = this.directionx * -1;
            }
            else if (this.y >= 380) {
                this.directiony = this.directiony * -1;
            }
            else if (this.y <= 19) {
                this.directiony = this.directiony * -1;
            }
        }

        void collisionCheck () {
            if(this.x <= 45 || this.x >= 350) {
                if (dist(spielBall.x, spielBall.y, player1.collisioncheckx, player1.collisionchecky) >= 20 &&
                        dist(spielBall.x, spielBall.y, player1.collisioncheckx, player1.collisionchecky) <= 60) {
                    this.directionx = directionx * -1;
                }
                if (dist(spielBall.x, spielBall.y, player2.collisioncheckx, player2.collisionchecky) >= 20 &&
                        dist(spielBall.x, spielBall.y, player2.collisioncheckx, player2.collisionchecky) <= 30) {
                    this.directionx = directionx * -1;
                }
            }
        }
    }
}