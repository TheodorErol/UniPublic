package tcpong;

import processing.core.PApplet;

abstract class PongServer {
    public static void main(String[] args) {
        var pg = PongGame.newServer(8080);
        PApplet.runSketch(new String[]{"PongGame"}, pg);
    }

}